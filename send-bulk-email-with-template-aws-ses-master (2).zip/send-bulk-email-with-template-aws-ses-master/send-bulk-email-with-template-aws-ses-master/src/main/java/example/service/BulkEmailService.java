package example.service;

public interface BulkEmailService {

	public void sendBulkEmailAWSSES();

	void createTemplate();

	void deleteTemplate();
	
	

}
