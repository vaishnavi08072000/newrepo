package example.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailService;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceClientBuilder;

@Configuration
public class AWSSESConfig {
	
	 @Value("AKIA2LY3VT7SUDSY5XBT")
	 private String accessKeyId;
	 
	 @Value("eeH3O2nu6Sw+OsixMGMgUBsZuti0LFcPVnJU7EUV")
	 private String secretAccessKey;
	 
	 @Value("ap-northeast-1")
	 private String region;
	 
	 
	 @Bean
	    public AmazonSimpleEmailService getAmazonSESCient() {
		 
	 final BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials(accessKeyId, secretAccessKey);
	 	 
	 AmazonSimpleEmailService client = AmazonSimpleEmailServiceClientBuilder.standard()
             .withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials))
             .withRegion(region)
             .build();

         return client;
		 
	 }

}
