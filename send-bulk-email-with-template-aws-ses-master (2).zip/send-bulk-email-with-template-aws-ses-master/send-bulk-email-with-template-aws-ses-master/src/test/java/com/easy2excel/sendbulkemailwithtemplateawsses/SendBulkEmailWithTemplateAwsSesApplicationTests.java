package com.easy2excel.sendbulkemailwithtemplateawsses;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SendBulkEmailWithTemplateAwsSesApplicationTests {

	@Test
	void contextLoads() {
	}

}
